module.exports = { a: 1 };
