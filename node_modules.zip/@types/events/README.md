# Installation
> `npm install --save @types/events`

# Summary
This package contains type definitions for events (https://github.com/Gozala/events).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/events

Additional Details
 * Last updated: Thu, 24 Jan 2019 03:19:08 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Yasunori Ohoka <https://github.com/yasupeke>, Shenwei Wang <https://github.com/weareoutman>.
