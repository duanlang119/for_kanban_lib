# Installation
> `npm install --save @types/bytebuffer`

# Summary
This package contains type definitions for bytebuffer.js ( https://github.com/dcodeIO/bytebuffer.js ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bytebuffer

Additional Details
 * Last updated: Tue, 29 Jan 2019 00:32:10 GMT
 * Dependencies: @types/long, @types/node
 * Global values: ByteBuffer

# Credits
These definitions were written by Denis Cappellin <https://github.com/cappellin>.
