# Unreleased
- [changed] Internal transport protocol update from proto2 to proto3.